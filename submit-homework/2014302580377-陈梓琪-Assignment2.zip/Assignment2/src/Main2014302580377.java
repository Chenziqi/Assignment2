import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580377 {
	
	public static void main(String[] args) throws Exception{
		//����һ���ļ�
		try{
			FileOutputStream main2 = new FileOutputStream(new File("main.text"));
		
			PrintStream t = new PrintStream(main2);
			//����
			String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai%20Xin%20Ping";
		
			Document doc;
			doc = Jsoup.connect(url).get();
		
			//д������
			Element ename = doc.select("h3").first();
			t.println(ename.text());
			//����
			Elements einfo = doc.select("p");
		
			String first = einfo.get(0).text();
			t.println(first);	
			
			String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";    
			 Pattern regex = Pattern.compile(check);    
			 Matcher matcher = regex.matcher(first);    
			 
			 if(matcher.find()){
				 System.out.println(matcher.group(0));
			 }
			 
			 String regex2 = "^((/(/d{3}/))|(/d{3}/-))?13[0-9]/d{8}|15[89]/d{8}";
			 Pattern pattern1 = Pattern.compile(regex2);
			 Matcher matcher1 = pattern1.matcher(first);
			 if(matcher1.find()){
				 System.out.println(matcher1.group(0));
			 }
		 
			t.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		}
}
